---
name: oracle-db
description: Oracle Database connection and query execution with multi-site profile support. Use when Kimi needs to connect to Oracle database, register multiple connection profiles (sites), retrieve schema information (tables, columns, constraints), view PL/SQL source code (procedures, functions, triggers, packages), or execute SQL queries.
---

# Oracle Database Skill

Connect to Oracle databases with multi-site profile management, explore schemas, and view PL/SQL source code.

## Prerequisites

```bash
pip install oracledb
```

## Workflow

### Multi-Profile System

Multiple database connections are managed as "sites" (profiles):
- `production` - Production database
- `staging` - Staging database  
- `dev` - Development database
- `client-a`, `client-b` - Client-specific databases

Profiles are stored in `~/.oracle_db_config.json`.

### Interactive Site Registration

When user wants to connect to Oracle DB:

1. Ask for site name
2. Check if site already exists - ask for overwrite confirmation
3. Collect connection details (host, port, service, username, password)
4. Save and test connection
5. Ask if this should be the default site

### Using Registered Sites

After registration, reference sites by name:

```bash
# Use specific site
python scripts/oracle_connector.py --site production --list-tables
python scripts/oracle_connector.py --site staging --query "SELECT * FROM users"

# Use default site (if configured)
python scripts/oracle_connector.py --list-tables
```

## Common Operations

### Site Management

```bash
# Register new site (interactive)
python scripts/oracle_connector.py --add-site

# List registered sites
python scripts/oracle_connector.py --list-sites

# Set default site
python scripts/oracle_connector.py --set-default staging

# Remove a site
python scripts/oracle_connector.py --remove-site dev
```

### Table Operations

```bash
# List all tables
python scripts/oracle_connector.py --list-tables

# Describe table structure
python scripts/oracle_connector.py --describe-table EMPLOYEES
```

### Procedures and Functions

```bash
# List all procedures and functions
python scripts/oracle_connector.py --list-procedures

# View source code of a procedure/function
python scripts/oracle_connector.py --procedure-source CALCULATE_SALARY
```

### Triggers

```bash
# List all triggers
python scripts/oracle_connector.py --list-triggers

# View source code of a trigger
python scripts/oracle_connector.py --trigger-source TRG_EMPLOYEE_AUDIT
```

### Packages

```bash
# List all packages
python scripts/oracle_connector.py --list-packages

# View package specification and body
python scripts/oracle_connector.py --package-source PKG_EMPLOYEE_UTILS

# View package body only
python scripts/oracle_connector.py --package-source PKG_EMPLOYEE_UTILS --package-body-only
```

### Query Execution

```bash
# Execute SQL query
python scripts/oracle_connector.py --query "SELECT * FROM employees WHERE ROWNUM <= 10"
```

## Conversation Examples

**User**: "Oracle DB production 사이트 등록해줘"  
→ Start interactive setup for "production" profile

**User**: "staging에서 테이블 목록 보여줘"  
→ Execute: `--site staging --list-tables`

**User**: "production에 있는 트리거 목록 보여줘"  
→ Execute: `--site production --list-triggers`

**User**: "TRG_EMP_AUDIT 트리거 소스 보여줘"  
→ Execute: `--trigger-source TRG_EMP_AUDIT`

**User**: "CALCULATE_BONUS 프로시저 내용 보여줘"  
→ Execute: `--procedure-source CALCULATE_BONUS`

**User**: "PKG_UTILS 패키지 소스 보여줘"  
→ Execute: `--package-source PKG_UTILS`

## Security

- Config file is stored at `~/.oracle_db_config.json`
- Set appropriate file permissions (600 recommended)
- Never commit credentials to version control
