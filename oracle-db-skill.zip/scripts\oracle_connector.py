#!/usr/bin/env python3
"""
Oracle Database Connector with Multi-Site Profile Support
Supports multiple database connections managed as named profiles/sites.
"""

import argparse
import json
import os
import sys
from typing import Optional, Dict, Any, List

try:
    import oracledb
except ImportError:
    print(json.dumps({
        "success": False,
        "error": "oracledb not installed. Run: pip install oracledb"
    }, indent=2))
    sys.exit(1)

CONFIG_PATH = os.path.expanduser("~/.oracle_db_config.json")


def load_config() -> Dict[str, Any]:
    """Load configuration file."""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            return json.load(f)
    return {"profiles": {}, "default_profile": None}


def save_config(config: Dict[str, Any]):
    """Save configuration file."""
    with open(CONFIG_PATH, 'w') as f:
        json.dump(config, f, indent=2)
    # Set restrictive permissions (Unix-like systems)
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except:
        pass


def get_profile_config(config: Dict[str, Any], site: Optional[str] = None) -> tuple[str, Dict[str, Any]]:
    """Get configuration for a specific profile or default."""
    if site:
        if site not in config["profiles"]:
            raise ValueError(f"Site '{site}' not found. Registered sites: {list(config['profiles'].keys())}")
        return site, config["profiles"][site]
    
    if config.get("default_profile") and config["default_profile"] in config["profiles"]:
        return config["default_profile"], config["profiles"][config["default_profile"]]
    
    if len(config["profiles"]) == 1:
        single_site = list(config["profiles"].keys())[0]
        return single_site, config["profiles"][single_site]
    
    if not config["profiles"]:
        raise ValueError("No profiles configured. Run with --add-site to add a site.")
    
    raise ValueError(f"Multiple sites available: {list(config['profiles'].keys())}. Specify --site or set a default.")


def connect(config: Dict[str, Any]):
    """Create database connection."""
    if config.get("service_name"):
        dsn = oracledb.makedsn(
            host=config["host"],
            port=config["port"],
            service_name=config["service_name"]
        )
    elif config.get("sid"):
        dsn = oracledb.makedsn(
            host=config["host"],
            port=config["port"],
            sid=config["sid"]
        )
    else:
        raise ValueError("Either service_name or sid must be specified")
    
    return oracledb.connect(
        user=config["user"],
        password=config["password"],
        dsn=dsn
    )


def test_connection(config: Dict[str, Any]) -> tuple[bool, str]:
    """Test database connection."""
    try:
        conn = connect(config)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM dual")
        cursor.close()
        conn.close()
        return True, "Connection successful"
    except Exception as e:
        return False, str(e)


def interactive_add_site(site_name: Optional[str] = None):
    """Interactive setup for a new site profile."""
    config = load_config()
    
    print("=" * 50, file=sys.stderr)
    print("Oracle Database Site Registration", file=sys.stderr)
    print("=" * 50, file=sys.stderr)
    
    # Get site name
    if not site_name:
        existing = list(config["profiles"].keys())
        if existing:
            print(f"\nExisting sites: {', '.join(existing)}", file=sys.stderr)
        site_name = input("\nSite name (e.g., production, staging, dev): ").strip()
    
    if not site_name:
        print("Error: Site name is required", file=sys.stderr)
        sys.exit(1)
    
    # Check if exists
    if site_name in config["profiles"]:
        overwrite = input(f"Site '{site_name}' already exists. Overwrite? (y/N): ").strip().lower()
        if overwrite != 'y':
            print("Cancelled.", file=sys.stderr)
            return
    
    # Collect connection details
    profile = {}
    profile["host"] = input("Host (e.g., localhost, db.company.com): ").strip()
    
    port_input = input("Port [1521]: ").strip()
    profile["port"] = int(port_input) if port_input else 1521
    
    service_input = input("Service Name (e.g., ORCL, XE) [ORCL]: ").strip()
    profile["service_name"] = service_input if service_input else "ORCL"
    
    profile["user"] = input("Username: ").strip()
    profile["password"] = input("Password: ")  # No strip for password
    
    # Test connection
    print(f"\nTesting connection to {site_name}...", file=sys.stderr)
    success, message = test_connection(profile)
    
    if not success:
        print(f"✗ Connection failed: {message}", file=sys.stderr)
        retry = input("Save anyway? (y/N): ").strip().lower()
        if retry != 'y':
            print("Cancelled.", file=sys.stderr)
            return
    else:
        print(f"✓ Connection successful!", file=sys.stderr)
    
    # Save profile
    config["profiles"][site_name] = profile
    
    # Ask for default
    if len(config["profiles"]) == 1:
        config["default_profile"] = site_name
        print(f"✓ Set as default site", file=sys.stderr)
    else:
        set_default = input(f"\nSet '{site_name}' as default site? (y/N): ").strip().lower()
        if set_default == 'y':
            config["default_profile"] = site_name
            print(f"✓ Set as default site", file=sys.stderr)
    
    save_config(config)
    print(f"\n✓ Site '{site_name}' saved to: {CONFIG_PATH}", file=sys.stderr)


def list_sites():
    """List all registered sites."""
    config = load_config()
    
    if not config["profiles"]:
        print(json.dumps({
            "success": True,
            "message": "No sites registered",
            "sites": [],
            "default": None
        }, indent=2))
        return
    
    sites = []
    for name, profile in config["profiles"].items():
        sites.append({
            "name": name,
            "host": profile["host"],
            "port": profile["port"],
            "service": profile.get("service_name") or profile.get("sid"),
            "user": profile["user"],
            "is_default": name == config.get("default_profile")
        })
    
    print(json.dumps({
        "success": True,
        "sites": sites,
        "default": config.get("default_profile")
    }, indent=2))


def set_default_site(site_name: str):
    """Set the default site."""
    config = load_config()
    
    if site_name not in config["profiles"]:
        print(json.dumps({
            "success": False,
            "error": f"Site '{site_name}' not found. Available: {list(config['profiles'].keys())}"
        }, indent=2))
        sys.exit(1)
    
    config["default_profile"] = site_name
    save_config(config)
    
    print(json.dumps({
        "success": True,
        "message": f"'{site_name}' is now the default site"
    }, indent=2))


def remove_site(site_name: str):
    """Remove a site profile."""
    config = load_config()
    
    if site_name not in config["profiles"]:
        print(json.dumps({
            "success": False,
            "error": f"Site '{site_name}' not found"
        }, indent=2))
        sys.exit(1)
    
    del config["profiles"][site_name]
    
    if config.get("default_profile") == site_name:
        config["default_profile"] = None
        if config["profiles"]:
            config["default_profile"] = list(config["profiles"].keys())[0]
    
    save_config(config)
    
    print(json.dumps({
        "success": True,
        "message": f"Site '{site_name}' removed"
    }, indent=2))


# Database Operations
def list_tables(conn) -> Dict[str, Any]:
    """List all tables in the current schema."""
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT table_name, num_rows, last_analyzed
            FROM user_tables
            ORDER BY table_name
        """)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        
        return {
            "success": True,
            "data": [dict(zip(columns, row)) for row in rows],
            "columns": columns,
            "row_count": len(rows)
        }
    finally:
        cursor.close()


def describe_table(conn, table_name: str) -> Dict[str, Any]:
    """Get column information for a table."""
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT column_name, data_type, data_length, nullable, data_default
            FROM user_tab_columns
            WHERE table_name = :table_name
            ORDER BY column_id
        """, {"table_name": table_name.upper()})
        
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        
        if not rows:
            return {
                "success": False,
                "error": f"Table '{table_name}' not found"
            }
        
        return {
            "success": True,
            "data": [dict(zip(columns, row)) for row in rows],
            "columns": columns,
            "row_count": len(rows)
        }
    finally:
        cursor.close()


def execute_query(conn, query: str) -> Dict[str, Any]:
    """Execute a SQL query and return results."""
    cursor = conn.cursor()
    try:
        cursor.execute(query)
        
        if cursor.description is None:
            conn.commit()
            return {
                "success": True,
                "message": f"Query executed. Rows affected: {cursor.rowcount}",
                "row_count": cursor.rowcount
            }
        
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        
        # Convert rows to dictionaries
        data = []
        for row in rows:
            row_dict = {}
            for col, val in zip(columns, row):
                if hasattr(val, 'isoformat'):
                    row_dict[col] = val.isoformat()
                elif isinstance(val, bytes):
                    row_dict[col] = f"<BLOB: {len(val)} bytes>"
                else:
                    row_dict[col] = val
            data.append(row_dict)
        
        return {
            "success": True,
            "data": data,
            "columns": columns,
            "row_count": len(rows)
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
    finally:
        cursor.close()


def get_schema_info(conn) -> Dict[str, Any]:
    """Get comprehensive schema information."""
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT 
                t.table_name,
                t.num_rows,
                COUNT(c.column_name) as column_count
            FROM user_tables t
            LEFT JOIN user_tab_columns c ON t.table_name = c.table_name
            GROUP BY t.table_name, t.num_rows
            ORDER BY t.table_name
        """)
        
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        
        return {
            "success": True,
            "data": [dict(zip(columns, row)) for row in rows],
            "columns": columns,
            "row_count": len(rows)
        }
    finally:
        cursor.close()


# Procedures and Functions
def list_procedures(conn) -> Dict[str, Any]:
    """List all procedures and functions."""
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT object_name, object_type, status, created, last_ddl_time
            FROM user_objects
            WHERE object_type IN ('PROCEDURE', 'FUNCTION')
            ORDER BY object_type, object_name
        """)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        
        return {
            "success": True,
            "data": [dict(zip(columns, row)) for row in rows],
            "columns": columns,
            "row_count": len(rows)
        }
    finally:
        cursor.close()


def get_procedure_source(conn, procedure_name: str) -> Dict[str, Any]:
    """Get source code of a procedure or function."""
    cursor = conn.cursor()
    try:
        # Check if it exists
        cursor.execute("""
            SELECT object_type, status
            FROM user_objects
            WHERE object_name = :name
            AND object_type IN ('PROCEDURE', 'FUNCTION')
        """, {"name": procedure_name.upper()})
        
        obj_info = cursor.fetchone()
        if not obj_info:
            return {
                "success": False,
                "error": f"Procedure or function '{procedure_name}' not found"
            }
        
        # Get source code
        cursor.execute("""
            SELECT line, text
            FROM user_source
            WHERE name = :name
            AND type IN ('PROCEDURE', 'FUNCTION')
            ORDER BY line
        """, {"name": procedure_name.upper()})
        
        rows = cursor.fetchall()
        source_lines = [row[1] for row in rows]
        source_code = ''.join(source_lines)
        
        return {
            "success": True,
            "object_name": procedure_name.upper(),
            "object_type": obj_info[0],
            "status": obj_info[1],
            "source": source_code,
            "line_count": len(rows)
        }
    finally:
        cursor.close()


# Triggers
def list_triggers(conn) -> Dict[str, Any]:
    """List all triggers."""
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT trigger_name, table_name, status, triggering_event,
                   trigger_type
            FROM user_triggers
            ORDER BY trigger_name
        """)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        
        return {
            "success": True,
            "data": [dict(zip(columns, row)) for row in rows],
            "columns": columns,
            "row_count": len(rows)
        }
    finally:
        cursor.close()


def get_trigger_source(conn, trigger_name: str) -> Dict[str, Any]:
    """Get source code of a trigger."""
    cursor = conn.cursor()
    try:
        # Check if it exists
        cursor.execute("""
            SELECT status, table_name, triggering_event, trigger_type
            FROM user_triggers
            WHERE trigger_name = :name
        """, {"name": trigger_name.upper()})
        
        trig_info = cursor.fetchone()
        if not trig_info:
            return {
                "success": False,
                "error": f"Trigger '{trigger_name}' not found"
            }
        
        # Get source code
        cursor.execute("""
            SELECT line, text
            FROM user_source
            WHERE name = :name
            AND type = 'TRIGGER'
            ORDER BY line
        """, {"name": trigger_name.upper()})
        
        rows = cursor.fetchall()
        source_lines = [row[1] for row in rows]
        source_code = ''.join(source_lines)
        
        return {
            "success": True,
            "trigger_name": trigger_name.upper(),
            "table_name": trig_info[1],
            "status": trig_info[0],
            "triggering_event": trig_info[2],
            "trigger_type": trig_info[3],
            "source": source_code,
            "line_count": len(rows)
        }
    finally:
        cursor.close()


# Packages
def list_packages(conn) -> Dict[str, Any]:
    """List all packages."""
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT object_name, object_type, status, created, last_ddl_time
            FROM user_objects
            WHERE object_type IN ('PACKAGE', 'PACKAGE BODY')
            ORDER BY object_name, object_type
        """)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        
        return {
            "success": True,
            "data": [dict(zip(columns, row)) for row in rows],
            "columns": columns,
            "row_count": len(rows)
        }
    finally:
        cursor.close()


def get_package_source(conn, package_name: str, body_only: bool = False) -> Dict[str, Any]:
    """Get source code of a package (spec and/or body)."""
    cursor = conn.cursor()
    try:
        types = ['PACKAGE BODY'] if body_only else ['PACKAGE', 'PACKAGE BODY']
        
        result = {
            "success": True,
            "package_name": package_name.upper(),
            "spec": None,
            "body": None
        }
        
        for pkg_type in types:
            cursor.execute("""
                SELECT line, text
                FROM user_source
                WHERE name = :name
                AND type = :type
                ORDER BY line
            """, {"name": package_name.upper(), "type": pkg_type})
            
            rows = cursor.fetchall()
            if rows:
                source_lines = [row[1] for row in rows]
                source_code = ''.join(source_lines)
                
                if pkg_type == 'PACKAGE':
                    result["spec"] = {
                        "source": source_code,
                        "line_count": len(rows)
                    }
                else:
                    result["body"] = {
                        "source": source_code,
                        "line_count": len(rows)
                    }
        
        if not result["spec"] and not result["body"]:
            return {
                "success": False,
                "error": f"Package '{package_name}' not found"
            }
        
        return result
    finally:
        cursor.close()


def main():
    parser = argparse.ArgumentParser(description="Oracle Database Connector")
    parser.add_argument("--site", help="Site/profile name to use")
    parser.add_argument("--add-site", action="store_true", help="Add new site interactively")
    parser.add_argument("--site-name", help="Name for new site (with --add-site)")
    parser.add_argument("--list-sites", action="store_true", help="List all registered sites")
    parser.add_argument("--set-default", help="Set default site")
    parser.add_argument("--remove-site", help="Remove a site")
    parser.add_argument("--list-tables", action="store_true", help="List all tables")
    parser.add_argument("--describe-table", help="Describe table structure")
    parser.add_argument("--query", help="Execute SQL query")
    parser.add_argument("--schema-info", action="store_true", help="Get schema summary")
    parser.add_argument("--test", action="store_true", help="Test connection")
    
    # Procedure/Function commands
    parser.add_argument("--list-procedures", action="store_true", help="List all procedures and functions")
    parser.add_argument("--procedure-source", help="Get source code of a procedure/function")
    
    # Trigger commands
    parser.add_argument("--list-triggers", action="store_true", help="List all triggers")
    parser.add_argument("--trigger-source", help="Get source code of a trigger")
    
    # Package commands
    parser.add_argument("--list-packages", action="store_true", help="List all packages")
    parser.add_argument("--package-source", help="Get source code of a package")
    parser.add_argument("--package-body-only", action="store_true", help="Get only package body (with --package-source)")
    
    args = parser.parse_args()
    
    # Profile management commands
    if args.add_site:
        interactive_add_site(args.site_name)
        return
    
    if args.list_sites:
        list_sites()
        return
    
    if args.set_default:
        set_default_site(args.set_default)
        return
    
    if args.remove_site:
        remove_site(args.remove_site)
        return
    
    # Database operations - need profile
    try:
        config = load_config()
        site_name, profile_config = get_profile_config(config, args.site)
        
        if args.test:
            success, message = test_connection(profile_config)
            print(json.dumps({
                "success": success,
                "site": site_name,
                "message": message
            }, indent=2))
            return
        
        conn = connect(profile_config)
        
        if args.list_tables:
            result = list_tables(conn)
        elif args.describe_table:
            result = describe_table(conn, args.describe_table)
        elif args.query:
            result = execute_query(conn, args.query)
        elif args.schema_info:
            result = get_schema_info(conn)
        elif args.list_procedures:
            result = list_procedures(conn)
        elif args.procedure_source:
            result = get_procedure_source(conn, args.procedure_source)
        elif args.list_triggers:
            result = list_triggers(conn)
        elif args.trigger_source:
            result = get_trigger_source(conn, args.trigger_source)
        elif args.list_packages:
            result = list_packages(conn)
        elif args.package_source:
            result = get_package_source(conn, args.package_source, args.package_body_only)
        else:
            print(json.dumps({
                "success": False,
                "error": "No operation specified",
                "site": site_name
            }, indent=2))
            sys.exit(1)
        
        result["site"] = site_name
        print(json.dumps(result, indent=2, default=str))
        
    except ValueError as e:
        print(json.dumps({
            "success": False,
            "error": str(e)
        }, indent=2))
        sys.exit(1)
    except oracledb.Error as e:
        print(json.dumps({
            "success": False,
            "error": f"Oracle Error: {str(e)}"
        }, indent=2))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": str(e)
        }, indent=2))
        sys.exit(1)
    finally:
        if 'conn' in locals():
            conn.close()


if __name__ == "__main__":
    main()
