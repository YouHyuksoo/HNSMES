# Multi-Site Usage Examples

Oracle DB 스킬을 사용하여 여러 데이터베이스를 관리하는 예제입니다.

## Initial Setup

### 1. Register Production Site

```bash
python scripts/oracle_connector.py --add-site --site-name production
```

Interactive prompts:
```
Host (e.g., localhost, db.company.com): prod.db.company.com
Port [1521]: 1521
Service Name (e.g., ORCL, XE) [ORCL]: PROD
Username: app_user
Password: ********

Testing connection to production...
✓ Connection successful!
✓ Set as default site
```

### 2. Register Staging Site

```bash
python scripts/oracle_connector.py --add-site --site-name staging
```

## Managing Sites

### List All Sites

```bash
python scripts/oracle_connector.py --list-sites
```

Output:
```json
{
  "success": true,
  "sites": [
    {
      "name": "production",
      "host": "prod.db.company.com",
      "port": 1521,
      "service": "PROD",
      "user": "app_user",
      "is_default": true
    },
    {
      "name": "staging",
      "host": "staging.db.company.com",
      "port": 1521,
      "service": "STAGING",
      "user": "app_user",
      "is_default": false
    }
  ],
  "default": "production"
}
```

### Change Default Site

```bash
python scripts/oracle_connector.py --set-default staging
```

### Remove a Site

```bash
python scripts/oracle_connector.py --remove-site staging
```

## Query Execution by Site

### Using Specific Site

```bash
# Production
python scripts/oracle_connector.py --site production --list-tables

# Staging
python scripts/oracle_connector.py --site staging --list-tables

# Development
python scripts/oracle_connector.py --site dev --query "SELECT * FROM test_users"
```

### Using Default Site

```bash
# Uses default (production)
python scripts/oracle_connector.py --list-tables
```

## Conversation Flow Examples

### Scenario 1: First Time Setup

**User**: "Oracle DB 등록해줘"

**Kimi**: 
1. "사이트 이름을 입력해주세요 (예: production, staging, dev):" → `production`
2. "호스트를 입력해주세요:" → `db.company.com`
3. "포트 번호 [1521]:" → `1521`
4. "Service Name [ORCL]:" → `PROD`
5. "사용자 이름:" → `admin`
6. "비밀번호:" → `*****`
7. Test connection and save

### Scenario 2: Query Specific Site

**User**: "staging에서 employees 테이블 보여줘"

**Kimi** executes:
```bash
python scripts/oracle_connector.py --site staging --describe-table employees
```

### Scenario 3: Switch Default

**User**: "기본 사이트를 staging으로 바꿔줘"

**Kimi** executes:
```bash
python scripts/oracle_connector.py --set-default staging
```

## Config File Format

`~/.oracle_db_config.json`:
```json
{
  "profiles": {
    "production": {
      "host": "prod.db.com",
      "port": 1521,
      "service_name": "PROD",
      "user": "app_user",
      "password": "secret"
    },
    "staging": {
      "host": "staging.db.com",
      "port": 1521,
      "service_name": "STAGING",
      "user": "app_user",
      "password": "secret"
    },
    "dev": {
      "host": "localhost",
      "port": 1521,
      "service_name": "XE",
      "user": "system",
      "password": "password"
    }
  },
  "default_profile": "staging"
}
```
