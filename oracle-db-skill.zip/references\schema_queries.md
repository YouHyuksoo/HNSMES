# Oracle Schema Queries

Common queries for exploring Oracle database schemas.

## Table Information

### List All Tables
```sql
SELECT table_name, num_rows, last_analyzed
FROM user_tables
ORDER BY table_name;
```

### Tables with Primary Keys
```sql
SELECT t.table_name, c.constraint_name
FROM user_tables t
JOIN user_constraints c ON t.table_name = c.table_name
WHERE c.constraint_type = 'P'
ORDER BY t.table_name;
```

## Column Information

### All Columns in a Table
```sql
SELECT column_name, data_type, data_length, data_precision, data_scale, nullable
FROM user_tab_columns
WHERE table_name = 'TABLE_NAME'
ORDER BY column_id;
```

### Columns with Comments
```sql
SELECT c.column_name, c.data_type, cc.comments
FROM user_tab_columns c
LEFT JOIN user_col_comments cc ON c.table_name = cc.table_name 
    AND c.column_name = cc.column_name
WHERE c.table_name = 'TABLE_NAME';
```

## Constraints

### All Constraints on a Table
```sql
SELECT constraint_name, constraint_type, search_condition
FROM user_constraints
WHERE table_name = 'TABLE_NAME';
```

Constraint types:
- `P` = Primary Key
- `R` = Foreign Key
- `U` = Unique
- `C` = Check

### Foreign Key Relationships
```sql
SELECT 
    c.constraint_name,
    c.table_name,
    c.r_constraint_name as referenced_constraint,
    (SELECT table_name FROM user_constraints WHERE constraint_name = c.r_constraint_name) as referenced_table
FROM user_constraints c
WHERE c.constraint_type = 'R';
```

## Indexes

### Indexes on a Table
```sql
SELECT index_name, index_type, uniqueness
FROM user_indexes
WHERE table_name = 'TABLE_NAME';
```

### Index Columns
```sql
SELECT index_name, column_name, column_position
FROM user_ind_columns
WHERE table_name = 'TABLE_NAME'
ORDER BY index_name, column_position;
```

## Procedures and Functions

### List All Procedures and Functions
```sql
SELECT object_name, object_type, status, created, last_ddl_time
FROM user_objects
WHERE object_type IN ('PROCEDURE', 'FUNCTION')
ORDER BY object_type, object_name;
```

### Get Source Code of Procedure/Function
```sql
SELECT line, text
FROM user_source
WHERE name = 'PROCEDURE_NAME'
AND type IN ('PROCEDURE', 'FUNCTION')
ORDER BY line;
```

### Find Procedures/Functions by Pattern
```sql
SELECT object_name, object_type
FROM user_objects
WHERE object_type IN ('PROCEDURE', 'FUNCTION')
AND object_name LIKE '%PATTERN%';
```

## Triggers

### List All Triggers
```sql
SELECT trigger_name, table_name, status, triggering_event, trigger_type
FROM user_triggers
ORDER BY trigger_name;
```

### Get Source Code of Trigger
```sql
SELECT line, text
FROM user_source
WHERE name = 'TRIGGER_NAME'
AND type = 'TRIGGER'
ORDER BY line;
```

### Triggers on Specific Table
```sql
SELECT trigger_name, triggering_event, trigger_type, status
FROM user_triggers
WHERE table_name = 'TABLE_NAME';
```

## Packages

### List All Packages
```sql
SELECT object_name, object_type, status
FROM user_objects
WHERE object_type IN ('PACKAGE', 'PACKAGE BODY')
ORDER BY object_name, object_type;
```

### Get Package Specification
```sql
SELECT line, text
FROM user_source
WHERE name = 'PACKAGE_NAME'
AND type = 'PACKAGE'
ORDER BY line;
```

### Get Package Body
```sql
SELECT line, text
FROM user_source
WHERE name = 'PACKAGE_NAME'
AND type = 'PACKAGE BODY'
ORDER BY line;
```

## Data Dictionary Views

### Available Views
- `user_tables` - Tables owned by user
- `all_tables` - Tables accessible to user
- `dba_tables` - All tables (requires DBA privilege)
- `user_tab_columns` - Columns in user's tables
- `user_constraints` - Constraints on user's tables
- `user_indexes` - Indexes on user's tables
- `user_source` - Source code of stored objects
- `user_triggers` - Triggers owned by user
- `user_objects` - All objects owned by user
- `user_procedures` - Procedures and functions
