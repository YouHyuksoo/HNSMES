# Oracle-DB Skill for Claude Code

Oracle Database 연결 및 쿼리 실행을 위한 Claude Code 스킬입니다.

## 🚀 설치 방법

### 1. 사전 요구사항

```bash
# Python oracledb 패키지 설치
pip install oracledb
```

### 2. 스킬 폴더 복사

아래 폴더 구조를 `~/.claude/skills/oracle-db/`에 복사합니다:

**Windows 경로:** `C:\Users\<사용자명>\.claude\skills\oracle-db\`
**Mac/Linux 경로:** `~/.claude/skills/oracle-db/`

```
oracle-db/
├── SKILL.md                    # 스킬 정의 (필수)
├── scripts/
│   └── oracle_connector.py     # Python 커넥터 (필수)
└── references/
    ├── connection_examples.md  # 연결 예제
    ├── multi_site_examples.md  # 멀티사이트 예제
    └── schema_queries.md       # 스키마 쿼리 참조
```

### 3. 폴더 생성 및 복사 (Windows)

```powershell
# PowerShell에서 실행
mkdir -Force "$env:USERPROFILE\.claude\skills\oracle-db\scripts"
mkdir -Force "$env:USERPROFILE\.claude\skills\oracle-db\references"

# 파일 복사 (패키지 압축을 푼 위치에서)
Copy-Item "SKILL.md" "$env:USERPROFILE\.claude\skills\oracle-db\"
Copy-Item "scripts\oracle_connector.py" "$env:USERPROFILE\.claude\skills\oracle-db\scripts\"
Copy-Item "references\*" "$env:USERPROFILE\.claude\skills\oracle-db\references\"
```

### 4. Claude Code 재시작

설치 후 Claude Code를 재시작하면 스킬이 자동으로 인식됩니다.

---

## 📖 사용 방법

### DB 사이트 등록

Claude에게 말하세요:
- "Oracle DB production 사이트 등록해줘"
- "staging Oracle 연결 추가해줘"

### 테이블 조회

- "production에서 테이블 목록 보여줘"
- "EMPLOYEES 테이블 구조 보여줘"

### 쿼리 실행

- "staging에서 SELECT * FROM users WHERE ROWNUM <= 10 실행해줘"

### 프로시저/함수 소스 보기

- "CALCULATE_SALARY 프로시저 소스 보여줘"
- "production에 있는 함수 목록 보여줘"

### 트리거 보기

- "트리거 목록 보여줘"
- "TRG_AUDIT 트리거 소스 보여줘"

### 패키지 보기

- "PKG_UTILS 패키지 소스 보여줘"

---

## 🔐 설정 파일

DB 연결 정보는 `~/.oracle_db_config.json`에 저장됩니다.

```json
{
  "profiles": {
    "production": {
      "host": "prod.db.com",
      "port": 1521,
      "service_name": "PROD",
      "user": "app_user",
      "password": "secret"
    },
    "staging": {
      "host": "staging.db.com",
      "port": 1521,
      "service_name": "STAGING",
      "user": "app_user",
      "password": "secret"
    }
  },
  "default_profile": "production"
}
```

---

## 🛠️ 수동 테스트

스킬 설치 후 직접 테스트:

```bash
# 사이트 목록 확인
python ~/.claude/skills/oracle-db/scripts/oracle_connector.py --list-sites

# 사이트 추가 (대화형)
python ~/.claude/skills/oracle-db/scripts/oracle_connector.py --add-site

# 테이블 목록
python ~/.claude/skills/oracle-db/scripts/oracle_connector.py --list-tables

# 쿼리 실행
python ~/.claude/skills/oracle-db/scripts/oracle_connector.py --query "SELECT * FROM dual"
```

---

## ⚠️ 보안 주의사항

- `~/.oracle_db_config.json` 파일에 비밀번호가 저장됩니다
- 파일 권한을 600으로 설정하세요 (Linux/Mac)
- 절대 Git에 커밋하지 마세요
