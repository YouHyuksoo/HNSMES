# Oracle Connection Examples

## Environment Variables Setup

### Windows PowerShell
```powershell
$env:ORACLE_HOST = "localhost"
$env:ORACLE_PORT = "1521"
$env:ORACLE_SERVICE = "ORCL"
$env:ORACLE_USER = "scott"
$env:ORACLE_PASSWORD = "tiger"
```

### Windows Command Prompt
```cmd
set ORACLE_HOST=localhost
set ORACLE_PORT=1521
set ORACLE_SERVICE=ORCL
set ORACLE_USER=scott
set ORACLE_PASSWORD=tiger
```

### Linux/macOS (Bash)
```bash
export ORACLE_HOST=localhost
export ORACLE_PORT=1521
export ORACLE_SERVICE=ORCL
export ORACLE_USER=scott
export ORACLE_PASSWORD=tiger
```

## Config File Example

Create `~/.oracle_db_config.json`:
```json
{
  "host": "localhost",
  "port": 1521,
  "service_name": "ORCL",
  "user": "scott",
  "password": "tiger"
}
```

Or with SID instead of service name:
```json
{
  "host": "localhost",
  "port": 1521,
  "sid": "ORCL",
  "user": "scott",
  "password": "tiger"
}
```

## Using the Connector

### List Tables
```bash
python scripts/oracle_connector.py --list-tables
```

### Describe Table
```bash
python scripts/oracle_connector.py --describe-table EMPLOYEES
```

### Execute Query
```bash
python scripts/oracle_connector.py --query "SELECT * FROM employees WHERE ROWNUM <= 5"
```

### Using Specific Config File
```bash
python scripts/oracle_connector.py --config /path/to/config.json --list-tables
```

## Oracle Connection String Formats

### Service Name (Recommended)
```
hostname:port/service_name
```

### SID (Legacy)
```
hostname:port:SID
```

### TNS Names
Requires `tnsnames.ora` configuration.
